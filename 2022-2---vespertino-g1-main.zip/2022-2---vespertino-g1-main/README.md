![9c00e2d8dfa361dd12fa652314b5b25c](https://user-images.githubusercontent.com/114436302/230907856-35d04466-5b14-4220-a249-dda5232e9255.png)

![status-em desenvolvimento-green](https://user-images.githubusercontent.com/114436302/230909252-fff7807e-4151-43e7-b03b-7e0aa77fab13.svg)

# descrição do Projeto

Mapa com funcionabilidades para facilitar localização dos participantes durante o evento Conecta IF e otimizar sua experiencia durante evento.

# Índice 

- [Título e Imagem de capa](#Título-e-Imagem-de-capa)
- [Índice](#índice)
- [Descrição do Projeto](#descrição-do-projeto)
- [Status do Projeto](#status-do-Projeto)
- [Funcionalidades do projeto ](#funcionalidades-do-projeto)
- [Acesso ao Projeto](#acesso-ao-projeto)
- [Tecnologias utilizadas](#tecnologias-utilizadas)
- [Autores](#autores)
- [Conclusão](#conclusão)

# Tecnologias utilizadas

Até o momento com 1 semestre de desenvolvimento foi utilizado apenas HTML e CSS, mas tendo em mente adicionar um sistema de javascript e banco de dados no projeto

# Funcionalidades do projeto

- `Funcionalidade 1`: Através do aplicativo web fica mais fácil saber o horário e local de cada evento que esta acontecendo na semana de atividades;
- `Funcionalidade 2`: Primeira etapa do prototipo

https://user-images.githubusercontent.com/114436302/230911865-371bb5db-c5e0-40ad-ad96-5e4e5b205102.mp4

# Autores

| [<img src="https://avatars.githubusercontent.com/u/114436302?v=4" width=115><br><sub>Jaqueline Nobre</sub>](https://github.com/JaqueNobre) |

| [<img src="https://avatars.githubusercontent.com/u/114433767?v=4" width=115><br><sub>Guilherme Bastos</sub>](https://github.com/guilhermenascimentobastos) |

__________________________________________________________________________________________________________________________________________

# Conclusão
